package com.mop.a2023.p20215179

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import com.mop.a2023.p20215179.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    // 문자열에 담긴 수식을 계산하는 함수

    fun calculate(input:String): Int{

        var listOfNum = mutableListOf<Int>() // 숫자를 담을 가변 리스트
        var listOfOp = mutableListOf<Char>() // 연산자를 담을 가변 리스트
        var pNum:Int = 0 // 숫자 가변 리스트에 쓰일 포인터
        var pOp:Int = 0 // 연산자 가변 리스트에 쓰일 포인터
        var tmpStrNum:String = " " // 연산자를 제외한 숫자들을 저장할 임시 변수
        var tmpCh:Char // 반복문에서 문자열로부터 문자를 하나씩 가져올 임시 변수

        for(i in 0..input.length-1){
            if(tmpStrNum.equals(" ")){
                tmpStrNum = "" // 초기 선언을 공백 문자열로 했기 때문에 여기서 없애기
            }
            tmpCh = input.get(i) // 문자열에서 i번째 문자를 가져옴 (반복문을 통해 모든 문자를 차례로 가져옴)
            if(tmpCh == '+' || tmpCh == '-' || tmpCh == '*' || tmpCh == '/'){
                listOfNum.add(pNum++, tmpStrNum.toInt()) // 정수로 변환해 숫자 리스트에 추가
                listOfOp.add(pOp++, tmpCh) // 연산자 리스트에 추가
                tmpStrNum = "" // 임시 변수 초기화
                continue // 다음 i번째로 점프
            }
            tmpStrNum += "$tmpCh"
        }
        listOfNum.add(pNum++, tmpStrNum.toInt()) // 마지막 숫자 추가

        // 연산자 리스트가 빌 때까지
        while(listOfOp.isEmpty() == false){
            // 숫자 리스트의 첫번째 값과 두번째 값을 연산
            var num1:Int = listOfNum.get(0)
            var num2:Int = listOfNum.get(1)
            var op:Char = listOfOp.get(0)
            // 맨앞의 원소는 이미 사용했으므로 삭제
            listOfNum.removeAt(0)
            listOfNum.removeAt(0)
            listOfOp.removeAt(0)
            // 연산자에 따라 연산
            if(op == '+') listOfNum.add(0, num1 + num2)
            else if(op == '-') listOfNum.add(0, num1 - num2)
            else if(op == '*') listOfNum.add(0, num1 * num2)
            else if(op == '/') listOfNum.add(0, num1 / num2)
        }

        // 결과 리턴
        return listOfNum.get(0)

    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var input:String // 수식을 담을 문자열 변수
        var result:Int // 결과를 담을 변수
        var colors = arrayOf<String>("#FFADAD", "#FFD6A5", "#FDFFB6", "#E4F1EE", "#D9EDF8", "#DEDAF4") // 배경 색상을 문자열로 담은 배열
        var colorsPointer:Int // 배경 색상 배열에서 쓰일 포인터 변수
        var inputTextView = findViewById<TextView>(R.id.formula) // 사용자가 입력한 내용이 들어갈 텍스트뷰
        var resultTextView = findViewById<TextView>(R.id.result) // 계산 결과를 출력할 텍스트뷰
        var changeColorBtn = findViewById<androidx.appcompat.widget.AppCompatButton>(R.id.btnColor) // 배경 색상을 변경하는 버튼
        var layout = findViewById<LinearLayout>(R.id.background)

        // 데이터 초기화
        input = ""
        result = 0
        colorsPointer = 0
        inputTextView.text = ""
        resultTextView.text = "0"

        // 버튼 눌렀을 때 이벤트 처리
        binding.btnColor.setOnClickListener {
            colorsPointer++ // 다음 색상의 인덱스로 이동
            if(colorsPointer >= colors.size) colorsPointer = 0 // 배열의 끝까지 갔다면 다시 처음으로
            layout.setBackgroundColor(Color.parseColor(colors[colorsPointer])) // 레이아웃 색상 변경
        }
        // 'C' 눌렀을 때 처리
        binding.btnClear.setOnClickListener {
            input = "" // 문자열 초기화
            result = 0
            inputTextView.text = input // 텍스트 뷰를 초기화된 문자열로 변경
        }
        // '=' 눌렀을 때 처리
        binding.btnEqual.setOnClickListener {
            result = calculate(input)
            Log.d("Calculator-btn", "$result")
            resultTextView.text = "$result"
        }
        // '<-' (Back) 버튼 눌렀을 때 처리
        binding.btnBack.setOnClickListener {
            if(input.length >=1) input = input.substring(0, input.length-1) // 문자열의 마지막 원소 자르기
            inputTextView.text = input
            Log.d("Calculator-btn", "$input")
        }
        // 연산자 버튼 눌렀을 때 이벤트 처리 - input 문자열에 연산자를 하나씩 추가
        binding.btnAddition.setOnClickListener {
            input += "+"
            inputTextView.text = input
        }
        binding.btnSubtraction.setOnClickListener {
            input += "-"
            inputTextView.text = input
        }
        binding.btnMultiplication.setOnClickListener {
            input += "*"
            inputTextView.text = input
        }
        binding.btnDivision.setOnClickListener {
            input += "/"
            inputTextView.text = input
        }
        // 숫자 버튼 눌렀을 때 이벤트 처리 - input 문자열에 숫자를 하나씩 추가
        binding.btn0.setOnClickListener {
            input += "0"
            inputTextView.text = input
        }
        binding.btn1.setOnClickListener {
            input += "1"
            inputTextView.text = input
        }
        binding.btn2.setOnClickListener {
            input += "2"
            inputTextView.text = input
        }
        binding.btn3.setOnClickListener {
            input += "3"
            inputTextView.text = input
        }
        binding.btn4.setOnClickListener {
            input += "4"
            inputTextView.text = input
        }
        binding.btn5.setOnClickListener {
            input += "5"
            inputTextView.text = input
        }
        binding.btn6.setOnClickListener {
            input += "6"
            inputTextView.text = input
        }
        binding.btn7.setOnClickListener {
            input += "7"
            inputTextView.text = input
        }
        binding.btn8.setOnClickListener {
            input += "8"
            inputTextView.text = input
        }
        binding.btn9.setOnClickListener {
            input += "9"
            inputTextView.text = input
        }

    }

}